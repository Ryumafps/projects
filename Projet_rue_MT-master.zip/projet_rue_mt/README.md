Projet_rue_MTM
----------------------------------------
Jeudi 14 septembre 
* Morgan : - Squelette Projet_rue_MT
* Mounir : - Toit ( fonction triangle isocele)
* Thomas : - couleurs aléatoire
----------------------------------------

Vendredis 22 septembre
* Mounir & Thomas = finalisation du positionnement des portes et commencement du toit correction de la fonction aleatoire pour les étages des bâtiments

--------------------------------------------
Jeudi 28 septembre
* Morgan & Mounir implémentation de Toits fonctionnels
* Thomas: fenetre

------------------------------------------
Jeudi 05 octobre
* Mounir + Thomas création de la fonction qui fais des toits rectangles
* Mounir, Morgan, Thomas dessiner fenetre fonctionnels + ne dessine pas la fenetre si il y a la porte
* Morgan commence la fonction interpréte

-----------------------------

Jeudi 12 octobre
* Thomas + Mounir : fonction qui dessine un sol vert en dessous des batiments + route
* Thomas + Morgan + Mounir : avancement interpreteur

-------------------------------------------

6 Novembre 
* Thomas + Mounir : Ajout de la documentation de la plupart des fonctions ou amélioration de ces dernières

----------------------------------------------

8 novembre
* Thomas + Mounir : finition de l'interpreteur et de dessiner_rue_decrite