from rue import dessiner_rue_decrite as dessine
def triage() -> list:
    """
    Lit un fichier texte contenant des informations sur des immeubles d'une rue et renvoie une liste de listes.

    Returns:
    list[list[str]]: Une liste de listes où chaque sous-liste contient des informations sur un immeuble.
    Chaque sous-liste contient des chaînes de caractères séparées par des points-virgules (';').

    Note:
    Le fichier 'enfant.txt' doit être préalablement créé et doit contenir les informations des immeubles,
    chaque immeuble étant décrit sur une ligne séparée avec les informations séparées par des points-virgules.
    """
    # 1 - Création de l'objet-fichier : ouverture en mode r (read)
    obj_fichier = open('enfant.txt', 'r', encoding="utf-8")
    ti = []
    # 2 intérprétation
    ti.append(obj_fichier.readline().replace("\n","").split(';'))
    ti.append(obj_fichier.readline().replace("\n","").split(';'))
    ti.append(obj_fichier.readline().replace("\n","").split(';'))
    ti.append(obj_fichier.readline().replace("\n","").split(';'))
    # 3 - Fermeture de l'objet-fichier
    obj_fichier.close()
    return ti

def interpretation(info:list) -> dict :
    """
    Interprète les informations sur un immeuble à partir d'une liste de chaînes de caractères.

    Args:
    info (list[str]): Une liste de chaînes de caractères contenant les informations sur un immeuble.
        La liste doit contenir au moins 3 éléments dans l'ordre : couleur_facade, etage, toit.

    Returns:
    dict: Un dictionnaire contenant les informations interprétées de l'immeuble avec les clés suivantes :
        - 'couleur_facade': La couleur de la façade de l'immeuble.
        - 'etage': Le nombre d'étages de l'immeuble.
        - 'toit': La description du toit de l'immeuble.

    Exemple d'utilisation :
    info_immeuble = ['bleu', '5', '1']*
    description = interpretation(info_immeuble)
    """
    decrit = {'numero' : info[0] , 'couleur_facade' : info[1] , 'etage' : 80*int(info[2]), 'toit' : int(info[3]), 'p_porte': info[4]}
    return decrit

def interpretations(tab_rue:list) -> list:
    """
    Interprète les informations de tous les immeubles d'une rue à partir d'une liste de listes.

    Args:
    tab_rue (list[list[str]]): Une liste de listes contenant les informations sur tous les immeubles de la rue.
        Chaque sous-liste doit contenir au moins 3 éléments dans l'ordre : couleur_facade, etage, toit.

    Returns:
    list[dict]: Une liste de dictionnaires, où chaque dictionnaire contient les informations interprétées d'un immeuble.
    """
    dict_rue = []
    for immeuble in tab_rue :
        dict_rue.append(interpretation(immeuble))
    return dict_rue


td = triage()
rue = (interpretations(td))
dessine(rue)