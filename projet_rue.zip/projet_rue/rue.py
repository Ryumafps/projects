"""Ce fichier permet de dessiner une rue à l'aide des fonctions suivantes :
 
+ dessiner_rue_aleatoire()
+ dessiner_rue_decrite(rue:dict)
"""
 
 
# Importation
import random as rd
import dessiner
 
 
# Constantes
 
LARGEUR_IMMEUBLE = 140
 
 
# Fonction privées
 
def immeuble_aleatoire(numero:int) -> dict:
    """
    Cette fonction génère aléatoirement des informations sur un immeuble.

    Arguments:
        numero (int): Le numéro de l'immeuble.

    Returns:
        dict: Un dictionnaire contenant les informations générées, y compris la couleur de la façade, le nombre d'étages,
        la position de la porte d'entrée et la présence d'un toit."""
    
    informations = {}
    informations['couleur_facade'] = couleur_aleatoire()
    informations['numero'] = numero
    informations['etage'] = 80*rd.randint(2,5) # 80 est la hauteur de un étage
    informations['p_porte'] = rd.randint(0,2)  # Position de la porte
    informations['toit'] = rd.randint(0,1)
    return informations


def interpretation(info:list) -> dict :    # récupére et trie les informations
    info = info.split(';')
    decrit = {'quantité' : info[0] , 'couleur_façade' : info[1] , 'etage' : info[2], 'toit' : info[3] }  
    return decrit


def immeuble_decrit(numero:int) -> dict :
    """Dessine un immeuble comme la fonction immeuble aléatoire mais avec les informations que on lui donne, on choisit les parametres des immeubles
    """
    informations = {}
    informations['quantité'] = decrit['quantité']
    informations['couleur_facade'] = decrit['couleur_façade']
    informations['numero'] = numero
    informations['etage'] = decrit['etage']
    informations['p_porte'] = rd.randint(0,2)
    informations['toit'] = rd.randint(0,1)
    return informations
    
def couleur_aleatoire() -> str:
    palette = ('darkred', 'blue', 'purple', 'olive', 'green', 'gold', 'navy', 'silver')
    return rd.choice(palette)
 
def coordonnees_facade(immeuble:dict) -> tuple:
    """
    Cette fonction calcule les coordonnées de la base d'une façade d'un immeuble en fonction de son numéro.

    Arguments:
        immeuble (dict): Un dictionnaire contenant les informations de l'immeuble, notamment le numéro.

    Returns:
        tuple: Un tuple contenant les coordonnées (x, y) de la base de la façade."""

    x_gauche = -400 + 160 * int(immeuble['numero'])
    y_bas = -150
    return (x_gauche, y_bas)
     
def dessiner_facade(immeuble:dict) -> None:
    """
    Dessine la façade d'un immeuble en utilisant les informations fournies dans le dictionnaire 'immeuble'.

    Args:
    immeuble (dict): Un dictionnaire contenant les informations de l'immeuble.
        Le dictionnaire doit contenir au moins les clés suivantes :
        - 'couleur_facade': La couleur de la façade de l'immeuble.
        - 'etage': Le nombre d'étages de l'immeuble.

    Returns:
    None"""
    
    crayon = {}
    crayon['écriture'] = "grey"
    crayon['fond'] = immeuble['couleur_facade']
    crayon['épaisseur'] = 3
    x, y = coordonnees_facade(immeuble)
    cote = LARGEUR_IMMEUBLE 
    hauteur = int(immeuble['etage'])
    dessiner.rectangle(cote, hauteur, crayon, (x, y))
 
def dessiner_porte(immeuble:dict) -> None:
    """
    Dessine la porte de l'immeuble en utilisant les informations fournies dans le dictionnaire 'immeuble'.

    Args:
    immeuble (dict): Un dictionnaire contenant les informations de l'immeuble.
        Le dictionnaire doit contenir au moins les clés suivantes :
        - 'p_porte': Position de la porte sur la façade de l'immeuble (une valeur entre 0 et 1).
        Assurez-vous que 'p_porte' est défini dans le dictionnaire 'immeuble'.

    Returns:
    None"""
    crayon = {}
    crayon['écriture'] = "black"
    crayon['fond'] = 'saddlebrown'    #immeuble['couleur_porte'] dans ver.définitive
    crayon['épaisseur'] = 3
    cote = 30
    hauteur = 50
    x, y = coordonnees_facade(immeuble)  # désempaquatage du couple
    x = x + 12.5 + int(immeuble['p_porte']) * 42.5
    dessiner.rectangle(cote, hauteur, crayon, (x,y))
    
def dessiner_toit(immeuble : dict) -> None :
    """
    Dessine le toit de l'immeuble en utilisant les informations fournies dans le dictionnaire 'immeuble'.

    Arguments:
    immeuble (dict): Un dictionnaire contenant les informations de l'immeuble.

    Returns:
    None"""
    x, y = coordonnees_facade(immeuble)  # désempaquatage du couple
    y = y + int(immeuble['etage'])
    crayon = {}
    crayon['écriture'] = "black"
    crayon['fond'] = 'black'    #immeuble['couleur_porte'] dans ver.définitive
    crayon['épaisseur'] = 3
    if immeuble['toit'] == 0 :
        dessiner.triangle_isocele( 140 ,crayon, (x,y))
    else :
        dessiner.rectangle(160, 10 ,crayon,(x-10,y))


def dessiner_fenetre(immeuble:dict, etage, position)-> None:
    """
    Dessine une fenêtre sur la façade d'un immeuble à une certaine position d'étage et de position.

    Args:
        immeuble (dict): Un dictionnaire contenant les informations de l'immeuble.
        etage (int): Le numéro de l'étage où la fenêtre doit être dessinée.
        position (int): La position de la fenêtre sur l'étage."""
    crayon = {}
    crayon['écriture'] = 'black'
    crayon['fond'] = 'cyan'
    crayon['épaisseur'] = 3
    x, y = coordonnees_facade(immeuble)
    x = x + 12.5 + (30 + 12.5) * position
    y = y + 80 * etage + 20
    cote = 30
    if etage >= 1 or position != immeuble['p_porte']:
        dessiner.rectangle(cote, cote, crayon, (x,y))
        
    
def dessiner_fenetres(immeuble:dict) -> None:
    """
    Dessine les fenêtres sur la façade d'un immeuble en fonction de ses caractéristiques.

    Args:
        immeuble (dict): Un dictionnaire contenant les informations de l'immeuble.

    Cette fonction prend en entrée un dictionnaire 'immeuble' contenant les informations de l'immeuble, y compris le nombre d'étages.
    Elle parcourt ensuite chaque étage de l'immeuble et chaque position de fenêtre sur cet étage en utilisant une boucle imbriquée.
    Pour chaque étage et position, elle appelle la fonction 'dessiner_fenetre' pour dessiner une fenêtre sur la façade de l'immeuble."""
    
    for etage in range (int(immeuble['etage']) // 80):
        for position in range(3):
            dessiner_fenetre(immeuble, etage, position)
            

def dessiner_immeuble(immeuble:dict) -> None:
    """
    Dessine un immeuble en fonction de ses caractéristiques.

    Args:
        immeuble (dict): Un dictionnaire contenant les informations de l'immeuble."""
    dessiner_facade(immeuble)
    dessiner_fenetres(immeuble)
    dessiner_porte(immeuble)
    dessiner_toit(immeuble)
    
 
def dessiner_rue_aleatoire() -> None:
    """
    Dessine une rue avec des immeubles aléatoires.

    Cette fonction ne prend aucun argument en entrée. Elle génère aléatoirement les informations pour plusieurs immeubles en utilisant
    la fonction 'immeuble_aleatoire' et dessine ensuite ces immeubles en utilisant la fonction 'dessiner_immeuble'. La boucle 'for' permet de générer
    et dessiner plusieurs immeubles sur la rue."""
    for n in range(5):
        informations_immeuble = immeuble_aleatoire(n)
        dessiner_immeuble(informations_immeuble)
        
def dessiner_rue_decrite(rue:list) -> None:  # Dessine une rue à l'aide des paramétres donnés par immeuble_decrit
    # Transfert du Texte en données
    for immeuble in rue:
        informations_immeuble = immeuble
        dessiner_immeuble(informations_immeuble)
    
    

 
 
# Programme principal
 
if __name__ == '__main__':
    informations_feutre = {'écriture':"black", 'fond':'lightslategrey', 'épaisseur':5}
    dessiner.rectangle(5000,466, informations_feutre, (-1000,-620))
    informations_feutre = {'écriture':"", 'fond':'#00FF00', 'épaisseur':5}
    dessiner.rectangle(5000,350, informations_feutre, (-1000,-620))
    
    dessiner.ecran()
    dessiner_rue_aleatoire()
