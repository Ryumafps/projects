let a; // Variable qui stocke le premier chiffre.
let b; // Variable qui stocke le deuxième chiffre.
let c; // Variable qui stocke le troisième chiffre.

// C'est une fonction qui est déclenchée quand on clique sur le bouton "rollButton".
document.getElementById("rollButton").onclick = function(){ 

    a = Math.floor(Math.random() * 10); // Génère un chiffre aléatoire entre 0 et 9 .
    b = Math.floor(Math.random() * 10); // Génère un chiffre aléatoire entre 0 et 9 .
    c = Math.floor(Math.random() * 10); // Génère un chiffre aléatoire entre 0 et 9 .

    // Modifie le contenu des éléments avec les ID pour afficher les valeurs qui sont générées.
    document.getElementById("chiffre_1").innerHTML = a;
    document.getElementById("chiffre_2").innerHTML = b; 
    document.getElementById("chiffre_3").innerHTML = c; 

    verifie_chiffre(); // C'est un appelle à la fonction pour vérifier si il y a au moin deux chiffres qui sont identiques.
}

// C'est une fonction qui vérifie si les deux chiffres générés sont identiques.
function verifie_chiffre() {
if (a === b || b === c || a ===c) //Si le chiffre a est égal au chiffre b OU si le chiffre b est égal au chiffre c OU si le chiffre a est égal au chiffre c"
{window.alert("Vous avez gagné! Deux chiffres sont identiques !");} 
}

//Si vous voulez respecter le concept même du jeu, c'est-à-dire gagner en tombant sur 3 chiffres identiques, remplacez la ligne 22 par : "if (a === b && b === c)".