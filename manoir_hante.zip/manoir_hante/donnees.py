# Les importations
import random as rd
import time
import sys




sortie = "portail"


#Classes
class Monstre:
    """Classe permettant de créer des monstres"""
    def __init__(self, nom, dsc, img=None, obj=None) -> None:
        self.nom = nom
        self.dsc = dsc
        self.img = img
        self.obj = obj
        self.habilite = rd.randint(1,10)
        self.endurance = rd.randint(1,10)
        self.force = 2
        self.courage = rd.randint(1,10)
        self.objet_detenu = []
        self.lieux_precedents = None
        
        if "Squelette" in self.nom:
            self.habilite = 10
            self.endurance = 5
            self.force = 1
            self.courage = 8
            
        if "Carapateur" in self.nom:
            self.habilite = 8
            self.endurance = 4
            self.force = 1
            self.courage = 4
            
        if "BaronNashor" in self.nom:
            self.habilite = 10
            self.endurance = 6
            self.force = 8
            self.courage = 9
            
    def get_description(self : 'Monstre')-> str:
        """Nous renvoie la description du monstre"""
        return self.dsc
    
    def get_carac(self : 'Monstre') -> str:
        """Renvoie une chaîne de caractères représentant les caractéristiques du monstre"""
        return f"{self.nom} H{self.habilite} E{self.endurance} F{self.force} C{self.courage}"
    
    def est_hs(self : 'Monstre') -> bool:
        """Vérifie si le monstre est hors combat (endurance <= 0)"""
        if self.endurance <= 0:
            return True
        else:
            return False
    
    def subir_degats(self : 'Monstre', degats:int)->None:
        """Fonction qui inflige des dégâts au monstre.
        Si les dégâts sont négatifs, rien n'est effectuée"""
        if degats > 0:
            self.endurance -= degats
            
            
    def fuir(self: 'Monstre') -> bool:
        if self.lieux_precedents:
            piece_precedente = self.lieux_precedents.pop()
            self.lieu = piece_precedente
            print(f"{self.nom} a fui vers {self.lieu.nom}.")
            return True
        else:
            return False

    
class Personnage:
    """Classe permettant de créer des personnages"""
    def __init__(self, nom)-> None:
        self.nom = nom
        self.habilite = rd.randint(6, 9)
        self.endurance = rd.randint(8, 15)
        self.force = 2
        self.charisme = rd.randint(1, 10)
        self.vigilance = rd.randint(1, 10)
        self.discretion = rd.randint(1, 10)
        self.lieu = None
        self.lieux_precedents = []
        self.objets = []
    
    def subir_degats(self : 'Personnage', degats:int)->None:
        """Fonction qui inflige des dégâts au personnage et qui réduis son endurance.
        Si les dégâts sont négatifs, rien n'est effectuée"""
        if degats >= 0:
            self.endurance -= degats
            
    def est_hs(self : 'Personnage') -> bool:
        """Vérifie si le personnage est hors combat (endurance <= 0)"""
        return self.endurance <= 0
    
    def get_carac(self: 'Personnage'):
        """Renvoie une chaîne de caractères qui represente les caractéristiques du personnage"""
        return f"{self.nom} H{self.habilite} E{self.endurance} F{self.force} C{self.charisme} V{self.vigilance} D{self.discretion} (objet){self.objets}"
        
    def combattre_monstre_actuel(self:'Personnage') -> tuple|None:
        """Fonction qui verifie s'il y a un monstre dans le lieu actuel et le combat.
        Renvoie un tuple contenant le résultat et la description du combat."""
        if self.lieu and self.lieu.occupant:
            return self.combattre(self.lieu.occupant)
    
    def combattre(self:'Personnage', adversaire:'Monstre') -> tuple:
        """
        Effectue un combat entre le personnage et un monstre.

        Parameters:
        - self ('Personnage'): L'instance du personnage effectuant l'attaque.
        - adversaire ('Monstre'): L'instance du monstre contre lequel le personnage se bat.

        Returns:
        - tuple: Un tuple contenant le code de résultat et la description du combat.

        Code de Résultat :
        - 'x': Le combat n'est pas encore terminé.
        - 'MP': Les deux participants sont hors combat.
        - 'P': Le personnage est hors combat.
        - 'M': Le monstre est hors combat.
        - 'F': Le personnage a fui.

        Description :
        Le combat consiste en plusieurs étapes, où les scores de combat sont comparés, et des dégâts sont infligés en fonction du résultat.
        Les participants peuvent également subir des dégâts critiques ou être hors combat.

        """
        score_personnage = rd.randint(1, 6) + rd.randint(1, 6) + self.habilite
        score_monstre = rd.randint(1, 6) + rd.randint(1, 6) + adversaire.habilite
        result_code = 'x'
        
        while result_code == 'x':
            if score_personnage == score_monstre:
                self.subir_degats(1)
                adversaire.subir_degats(1)
                result_code = "x"
                result_desc = f"{self.nom} et {adversaire.nom} se blessent mutuellement."
                time.sleep(1)
                print(result_desc)
            elif score_personnage > score_monstre:
                adversaire.subir_degats(self.force)
                result_code = "x"
                result_desc = f"{self.nom} inflige {self.force} points de dégâts au {adversaire.nom}."
                time.sleep(1)
                print(result_desc)
            else:
                self.subir_degats(adversaire.force)
                result_code = "x"
                result_desc = f"{adversaire.nom} inflige {adversaire.force} points de dégâts au {self.nom}."
                time.sleep(0.5)
                print(result_desc)
                
            if rd.randint(1, 6) == rd.randint(1, 6):
                double_damage = self.force * 2
                adversaire.subir_degats(double_damage)
                result_desc += f" Coup critique ! {self.nom} inflige {double_damage} points de dégâts supplémentaires au {adversaire.nom}."
                time.sleep(0.5)
                print(result_desc)
            elif self.est_hs() and adversaire.est_hs():
                result_code = "MP"
                result_desc = f"{self.nom} et {adversaire.nom} sont tous les deux hors combat."
                time.sleep(0.5)
                print(result_desc)
                
            # Si le combat est difficile, on peut fuir
            if self.endurance < 10:     # si la santé du personnage est inferieur a 10
                if self.fuir():         # alors on appelle la méthode fuir() du personnage
                    result_code = "F"   # si la fuite réussit, alors mettre result_code à "F"
                    result_desc = f"{self.nom} a fui vers le lieu précédent."
                    print(result_desc)
                
            elif self.est_hs():
                result_code = "P"
                result_desc = f"{self.nom} est hors combat."
            elif adversaire.est_hs():
                result_code = "M"
                result_desc = f"{adversaire.nom} est hors combat."
                time.sleep(0.5)
                print(result_desc)
                
            # Si le combat est difficile, le monstre peut fuir
            if adversaire.endurance < 3:
                if adversaire.fuir():
                    result_code = "F"
                    result_desc = f"{adversaire.nom} a fui vers le lieu précédent."
                    print(result_desc)
                    return result_code, result_desc
                else:
                    print(f"{adversaire.nom} a tenté de fuir mais n'a pas réussi.")
            
            if adversaire.est_hs():
                # Monstre vaincu, vérifiez s'il a laissé un objet derrière
                if adversaire.obj:
                    # Le monstre a laissé un objet, ajoutez-le à la pièce actuelle
                    self.objets.append(adversaire.obj)
                    print(f"{adversaire.nom} a laissé un objet derrière : {adversaire.obj}")
            
            # Déplacement vers la pièce suivante si le combat est gagné
            if result_code != 'x':
                if result_code != "F" and not self.est_hs():
                    # Vérifier s'il y a une pièce voisine dans la direction actuelle
                    if self.lieu.nord and self.lieu.nord != self.lieux_precedents[-1]:
                        self.lieux_precedents.append(self.lieu)
                        self.lieu = self.lieu.nord
                    elif self.lieu.sud and self.lieu.sud != self.lieux_precedents[-1]:
                        self.lieux_precedents.append(self.lieu)
                        self.lieu = self.lieu.sud
                    elif self.lieu.est and self.lieu.est != self.lieux_precedents[-1]:
                        self.lieux_precedents.append(self.lieu)
                        self.lieu = self.lieu.est
                    elif self.lieu.ouest and self.lieu.ouest != self.lieux_precedents[-1]:
                        self.lieux_precedents.append(self.lieu)
                        self.lieu = self.lieu.ouest
                    else:
                        print("Il n'y a pas de pièce voisine dans cette direction.")
                        return result_code, result_desc
                return result_code, result_desc
            
                
                
            return result_code, result_desc
    
    
    
    def fuir(self: 'Personnage') -> bool:
        """Tente de fuir vers la pièce précédente.
           on renvoie True si la fuite est réussie, sinon False"""
        
        if self.lieux_precedents:
            # Récupérer la pièce précédente
            piece_precedente = self.lieux_precedents.pop()
            # Déplacer le personnage vers la pièce précédente
            self.lieu = piece_precedente
            print(f"Vous avez fui vers {self.lieu.nom}.")
            return True
        else:
            return False
            
    def traverser_discretement(self: 'Personnage') -> bool:
        """
        on tente de traverser discrètement une salle sans combattre.
        on renvoie True si la traversée est réussie, sinon False"""
        if self.lieu and self.lieu.occupant:
            if self.discretion > self.lieu.occupant.courage:
                print(f"{self.nom} traverse discrètement la salle sans être repéré par {self.lieu.occupant.nom}.")
                # Déplacement vers la pièce suivante
                if self.lieu.nord:
                    self.lieux_precedents.append(self.lieu)
                    self.lieu = self.lieu.nord
                elif self.lieu.sud:
                    self.lieux_precedents.append(self.lieu)
                    self.lieu = self.lieu.sud
                elif self.lieu.est:
                    self.lieux_precedents.append(self.lieu)
                    self.lieu = self.lieu.est
                elif self.lieu.ouest:
                    self.lieux_precedents.append(self.lieu)
                    self.lieu = self.lieu.ouest
                return True
            else:
                print(f"{self.nom} tente de traverser discrètement la salle, mais {self.lieu.occupant.nom} le repère.")
                return False
        else:
            print("Aucun lieu ou occupant trouvé.")
            return False

        
    
    def soigner(self : 'Personnage', soins : int) -> None:
        """Soigne le personnage en augmentant son endurance.
        Les soins ne peuvent pas dépasser 24."""
        if self.endurance != 24:
            self.endurance += soins
        if self.endurance > 24:
            self.endurance = 24
            
    def observer(self:'Personnage')-> str:
        """Renvoie une description du lieu actuel"""
        if self.lieu:
            return Lieu.decrire_lieu(self.lieu)
            
    def reflechir(self:'Personnage') -> str:
        """Renvoie les actions possibles dans le lieu actuel"""
        if self.lieu:
            actions = Lieu.decrire_actions_possibles(self.lieu)
            # Ajouter l'option pour traverser discrètement
            return actions
        
    def aller_nord(self:'Personnage') -> bool:
        """Déplace le personnage vers une direction spécifique (nord, sud, est ou ouest)
        si le lieu dans cette direction est disponible.
        Renvoie True si le déplacement est réussi, sinon False"""
        if not self.lieu.occupant and self.lieu.nord != None:
            self.lieux_precedents.append(self.lieu)
            self.lieu = self.lieu.nord
            return True
        else:
            return False
        
    def aller_sud(self:'Personnage') -> bool:
        """Déplace le personnage vers une direction spécifique (nord, sud, est ou ouest)
        si le lieu dans cette direction est disponible.
        Renvoie True si le déplacement est réussi, sinon False"""
        if not self.lieu.occupant and self.lieu.sud != None:
            self.lieux_precedents.append(self.lieu)
            self.lieu = self.lieu.sud
            return True
        else:
            return False
        
    def aller_est(self:'Personnage') -> bool:
        """Déplace le personnage vers une direction spécifique (nord, sud, est ou ouest)
        si le lieu dans cette direction est disponible.
        Renvoie True si le déplacement est réussi, sinon False"""
        if not self.lieu.occupant and self.lieu.est != None:
            self.lieux_precedents.append(self.lieu)
            self.lieu = self.lieu.est
            return True
        else:
            return False
        
    def aller_ouest(self:'Personnage') -> bool:
        """Déplace le personnage vers une direction spécifique (nord, sud, est ou ouest)
        si le lieu dans cette direction est disponible.
        Renvoie True si le déplacement est réussi, sinon False"""
        if not self.lieu.occupant and self.lieu.ouest != None:
            self.lieux_precedents.append(self.lieu)
            self.lieu = self.lieu.ouest
            return True
        else:
            return False

    def verifier_fin_jeu(self:'Personnage', sortie):
        """Vérifie si le personnage est à la sortie du jeu."""
        if self.lieu == sortie:
            print("Félicitations ! Vous avez atteint la sortie. Vous avez terminé le jeu !")
            sys.exit()
            return True
        return False
        
                
        
        
                
            
class Lieu:
    
    def __init__(self, nom, dsc, img) -> None:
        self.nom = nom
        self.dsc = dsc
        self.img = img
        self.nord = None
        self.sud = None
        self.est = None
        self.ouest = None
        self.occupant = None
        self.objets = []
        self.action_supp = None
        
    def decrire_lieu(self):
        """Renvoie une description de la salle et le monstre éventuellement présent
     
        :: param self(Lieu) :: une instance de Lieu
        :: return (str)     :: un string contenant la description globale
     
        """
        reponse = self.dsc
        
        # ... et ce code permet d'y rajouter la description du monstre éventuel ...
        if self.occupant:  # cela veut dire si self.occupant existe (n'est pas 0, vide ou None)
            reponse += f"\nLa salle contient également {self.occupant.nom} : {self.occupant.get_description()}"
        return reponse
    
    
    def decrire_actions_possibles(self):
        """
        Cette méthode décrit les actions possibles pour le joueur en fonction de sa position
        Les actions possibles sont les suivantes :
        - Combattre : Le joueur peut combattre un autre personnage présent dans la case (seulement si un autre personnage est présent).
        - Fuir : Le joueur peut fuir un autre personnage présent dans la case (seulement si un autre personnage est présent).       
        - Aller au Nord : Le joueur peut se déplacer vers le Nord.        
        - Aller au Sud : Le joueur peut se déplacer vers le Sud.        
        - Aller à l'Ouest : Le joueur peut se déplacer vers l'Ouest.        
        - Aller à l'Est : Le joueur peut se déplacer vers l'Est.
        - Ramasser Objet : Ramasse un objet si le monstre en drop un.
        Return :        
        (str) : Les actions possibles, sous forme de chaîne de caractères, avec les options de déplacement et de combat, le cas échéant.
        """
        actions = ""
        
        if self.occupant:
            actions += "C : Combattre " + self.occupant.nom + "\n"
            actions += "F : Fuir " + self.occupant.nom + "\n"
            actions += "D : Traverser discrètement " + self.occupant.nom + "\n"
            
        else:
            if self.nord:
                actions += "N : Aller au NORD \n"
            if self.sud:
                actions += "S : Aller au SUD \n"
            if self.est:
                actions += "E : Aller au EST \n"
            if self.ouest:
                actions += "O : Aller au OUEST \n"
            if self.objets:
                actions += "R: Ramasser Objet \n"

                
        return actions
    
    def set_occupant(self:'Lieu', occupant:'None|Monstre|Personnage') -> bool:
        '''Cette méthode permet dee mettre en place un occupant dans un lieu'''
        if not self.occupant or occupant.est_hs():
            self.occupant = occupant
            return True
        return False
            
class Manoir:
 
    def __init__(self):
 
        self.heros = None
        self.depart = None
        self.lieux = []
        self.monstres = []
 
def peupler_manoir():
 
    # Création du personnage du joueur 
    aventurier = Personnage("Yasuo")

 
    # Création et agencement des lieux   
    
    entree = Lieu("entree", "Vous êtes devant l'entree du manoir. Une solide porte en bois est entreouverte", "manoir.jpg")
    hall = Lieu("Hall", "Vous êtes dans le hall d'entree du manoir.", "hall.jpeg")
    salledutresor = Lieu("Salle Du Trésor", "C'est la salle ou le Nashor stock tous ses trésors, QUELLE CHANCE!", "salledutresor.png")
    salledunashor = Lieu('Salle Du Nashor', "la dernière salle du manoir, on dit qu'une bête féroce y habite. Au nord se trouve la SORTIE", "salledunashor.png")
    cuisine = Lieu("Cuisine", "Tout est très bien rangé dans cette cuisine. Un étrange plat mijote sur le feu.", "cuisine.png")
    portail = Lieu("Portail Magique", "Vous avez trouvé la sortie après toutes ses mésaventures. Bien jouez-vous êtes libres.", "jardinmagique.png")
 
    entree.nord = hall
    hall.sud = entree
    hall.est = cuisine
    hall.ouest = salledutresor
    cuisine.ouest = hall
    cuisine.nord = salledunashor
    salledunashor.sud = cuisine
    salledunashor.nord = portail
    portail.sud = salledunashor
    salledutresor.est = hall
    
    # Positionnement des monstres
    cuisine.occupant = Monstre("Carapateur", "C'est un monstre neutre présent dans le Manoir", "carap.png")
    salledutresor.occupant = Monstre("Squelette", "Un squelette semblant bouger seul et muni d'une épée", "squelette.png")
    salledunashor.occupant = Monstre("BaronNashor", "Le Baron Nashor est le plus puissant monstre du Manoir", "baron.png")
    
    # Création des monstres
    Carapateur = Monstre("Carapateur", "C'est un monstre neutre présent dans le Manoir", "carap.png", "Epée Longue")
    Squelette = Monstre("Squelette", "Un squelette semblant bouger seul et muni d'une épée", "squelette.png", "Armure Enchantée")
    BaronNashor = Monstre("BaronNashor", "Le Baron Nashor est le plus puissant monstre du Manoir", "baron.png")
 
    

    
    # Affectation d'un lieu de départ à l'aventurier
    aventurier.lieu = entree
 
    # Création du manoir  
    manoir = Manoir()
    manoir.heros = aventurier
    manoir.depart = aventurier.lieu
    manoir.lieux.append(entree)
    manoir.lieux.append(hall)
    manoir.lieux.append(cuisine)
    manoir.lieux.append(salledutresor)
    manoir.lieux.append(salledunashor)
    manoir.lieux.append(portail)
    
    manoir.monstres.append("Squelette")
    manoir.monstres.append("Carapateur")
    manoir.monstres.append("BaronNashor")
    
    
 
    return manoir
 


            
    
                       
# Le corps du module en lui-même (le "programme principal") avec un if __name__ == '__main__'
if __name__ == '__main__':
    m = peupler_manoir()