# Importations 

import interface  # Dépendances : PIL(Pillow) et tkinter
import pickle
import donnees
import sys

# Sauvegarde l'ancienne sortie standard
ancienne_sortie = sys.stdout
# Redirige la sortie vers un fichier
nom_fichier_sortie = "enregistrement.txt"
nouvelle_sortie = open(nom_fichier_sortie, "w")
sys.stdout = nouvelle_sortie
# Restaure l'ancienne sortie standard
sys.stdout = ancienne_sortie
# Ferme le fichier de sortie
nouvelle_sortie.close()

# Déclaration des fonctions

def ihm_signale_evenement(evenement:'tk.Event', manoir:'Manoir', ihm:'IHM') -> None:
    '''Fonction où on récupère des informations sur l'événément reçu via l'IHM'''
    
    # On récupère la touche sur laquelle on vient d'appuyer
    touche = evenement.char
    print(f"\nEVENEMENT RECU : {evenement}")  # Permet de voir le vrai événement
    print(f"CODE PERSO : {touche}")           # L'IHM permet de connaitre la touche utilisée
    
    # Il faut maintenant gérer l'événement : modifier les données et redemander une affichage à l'IHM
    destination = None
    h = manoir.heros
    if touche == 'N' or touche == 'n':
        if h.aller_nord():  # Si aller au nord est possible et c'est bien passé
            modifier_affichage(manoir, ihm)
            
    elif touche == 'V' or touche == 'v':
        try:
            manoir = charger_jeu("sauvegarde_jeu.pkl")
            modifier_affichage(manoir, ihm)
            print("Jeu chargé.")
        except FileNotFoundError:
            print("Aucune sauvegarde trouvée.")
            
        h = manoir.heros
    
    if touche == 'N' or touche == 'n':
        if h.aller_nord():  # Si on peut aller au nord et que cela a bien fonctionner
            modifier_affichage(manoir, ihm)
            
    if touche == 'S' or touche == 's':
        if h.aller_sud():  # Si on peut aller au sud et que cela a bien fonctionner
            modifier_affichage(manoir, ihm)
            
    if touche == 'O' or touche == 'o':
        if h.aller_ouest():  # Si on peut aller a l'ouest et que cela a bien fonctionner
            modifier_affichage(manoir, ihm)
            
    if touche == 'E' or touche == 'e':
        if h.aller_est():  # Si on peut aller a l'est et que cela a bien fonctionner
            modifier_affichage(manoir, ihm)
            
    if touche == 'C' or touche == 'c':
        if h.combattre_monstre_actuel():  # Si on peut combattre et que cela a bien fonctionner
            modifier_affichage(manoir, ihm)
            
    if touche == 'D' or touche == 'd':
        if h.traverser_discretement():  # Si on peut traverser discretement la pièce et que cela a bien fonctionner
            modifier_affichage(manoir, ihm)
            
    if touche == 'F' or touche == 'f':
        if h.fuir():  # Si on peut fuire et que cela a bien fonctionner
            modifier_affichage(manoir, ihm)
            


def modifier_affichage(manoir:'Manoir', ihm:'IHM') -> None:
    '''Modifie les 5 champs de l'interface graphique'''
    h = manoir.heros
    ihm.afficher_txt_1( h.observer() )   # affiche le texte descriptif
    ihm.afficher_txt_2( h.reflechir() )  # affiche les actions possibles
    ihm.afficher_txt_3( h.get_carac() )  # affiche les caractéristiques du héros
    ihm.afficher_img_1( h.lieu.img )   # affiche l'image éventuelle du lieu
    if h.lieu.occupant:
        ihm.afficher_img_2( h.lieu.occupant.img) # affiche l'image éventuelle du monstre
        
    
# PROGRAMME PRINCIPAL

# Création des données et de l'interface graphique
m = donnees.peupler_manoir()  # Création des données du manoir  
ihm = interface.IHM()         # Création de l'interface graphique

# gestion_jeu va récupérer les événements sur l'ihm
ihm.signaler_evenement(lambda event: ihm_signale_evenement(event, m, ihm))  

modifier_affichage(m, ihm)





